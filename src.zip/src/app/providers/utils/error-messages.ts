export const ErrorMessages = {
  BadRequest: 'Não foi possível.',
  Unexpected: 'Desculpe, um erro inesperado aconteceu.',
  InvalidKindOfUser: 'Apenas usuários administradores podem acessar esta aplicação.',
  UserNotExists: 'O e-mail ou a senha estão incorretos.'
};
